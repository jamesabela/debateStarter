import SwiftUI

struct ContentView: View {
    @State var debate1 = Int.random(in: 0...(events.count-1))
    @State var debate2 = Int.random(in: 0...(events.count-1))
    var body: some View {
        VStack {
            Image("daysthatshooktheworld")
            
            Text("Which was the more important event?")
                .font(.title2)
                .padding()
            Link("A. \(events[debate1][0])",
                 destination: URL(string: "\(events[debate1][3])")!)
                .font(.title)
                .foregroundColor(.blue)
                .multilineTextAlignment(.center)
            Text("\nVs\n")
                .font(.title)
            
            Link("B. \(events[debate2][0])",
                 destination: URL(string: "\(events[debate2][3])")!)
            .font(.title)
            .foregroundColor(.blue)
            .multilineTextAlignment(.center)
            
            Spacer()
            Text("Click on event for video")
            HStack{
            Button("New Prompt"){
                debate1 = Int.random(in: 0...(events.count-1))
                debate2 = Int.random(in: 0...(events.count-1))
                while (debate1 == debate2) {
                    debate2 = Int.random(in: 0...(events.count-1))
                }
            }
            .buttonStyle(.bordered)
            .padding()
                
                Button("⎘ Copy Debate"){
                    UIPasteboard.general.string = "A. \(events[debate1][0]) Vs B. \(events[debate2][0])"
                }
                .buttonStyle(.bordered)
                .padding()
            }
            }
        }
    }
