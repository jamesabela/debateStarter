import SwiftUI

struct ListView: View {
    var body: some View {
        VStack{
            Text("List of events")
            List() {
                ForEach((0...(events.count-1)), id: \.self) {
                    Link("\(events[$0][2]) \(events[$0][0])", destination: URL(string: "\(events[$0][3])")!)
                }
                }
                    
                    
                }
                
                }
}
