import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            TabView {
                ContentView()
                    .tabItem {
                        Label("Debate", systemImage: "person.3")
                    }
                ListView()
                    .tabItem {
                        Label("Event List", systemImage: "list.dash")
                    }
            }
        }
    }
}
// Image(systemName: "person.3")

